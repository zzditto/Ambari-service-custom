# -*- coding: utf-8 -*-

import sys, os, glob, pwd, grp, signal, time
from resource_management import *

reload(sys) 
sys.setdefaultencoding("utf-8")

class FlumeServer(Script):

    #Install flume
    def install(self,env):
        import params
        env.set_params(params)

        #create group
        try:
            grp.getgrnam(params.flume_group)
        except KeyError:
            Group(group_name=params.flume_group)

        #create user
        try:
            pwd.getpwnam(params.flume_user)
        except KeyError:
            User(username=params.flume_user,
                 gid=params.flume_group,
                 groups=[params.flume_group],
                 ignore_failures=True
                 )

        # Create directories
        Directory([params.flume_base_dir, params.pid_file_dir],
                  mode=0755,
                  cd_access='a',
                  owner=params.flume_user,
                  group=params.flume_group,
                  create_parents=True
                  )
        
        # Download flume
        cmd = format("cd {flume_base_dir}; wget {flume_download_url} -O flume.tar.gz")
        Execute(cmd, user=params.flume_user)

        # Install flume
        cmd = format("cd {flume_base_dir}; tar -xf flume.tar.gz --strip-components=1")
        Execute(cmd, user=params.flume_user)

        # Ensure all files owned by Kiflumebana user
        cmd = format("chown -R {flume_user}:{flume_group} {flume_base_dir}")
        Execute(cmd)

        # Remove flume installation file
        cmd = format("cd {flume_base_dir}; rm -fr flume.tar.gz")
        Execute(cmd, user=params.flume_user)

        Execute('echo "Flume1.7 install complete"')


    # configure flume
    def configure(self, env):
        import params
        env.set_params(params)

        env_configurations = params.config['configurations']['flume1.7-env']
        File(format("{flume_base_dir}/conf/flume-env.sh"),
             content=Template("flume.env.j2", configurations=env_configurations),
             owner=params.flume_user,
             group=params.flume_group
             )

        configurations = params.config['configurations']['flume1.7-conf']
        File(format("{flume_base_dir}/conf/myflume.conf"),
             content=Template("flume.conf.j2", configurations=configurations),
             owner=params.flume_user,
             group=params.flume_group
             )

        # log4j
        log_configurations = params.config['configurations']['flume-log4j-properties']
        File(format("{flume_base_dir}/conf/log4j.properties"),
             content=Template("log4j.j2", configurations=configurations),
             owner=params.flume_user,
             group=params.flume_group
             )


        cmd = format("chown -R {flume_user}:{flume_group} {flume_base_dir}")
        Execute(cmd)

        # Make sure pid directory exist
        Directory([params.pid_file_dir,params.flume_log_dir],
                  mode=0755,
                  cd_access='a',
                  owner=params.flume_ng_user,
                  group=params.flume_group,
                  create_parents=True
                  )
        
        Execute('echo "Configuration complete"')

    def stop(self, env):
        import params
        env.set_params(params)

        # Stop flume
        """
            Kill the process by pid file, then check the process is running or not. If the process is still running after the kill
            command, it will try to kill with -9 option (hard kill)
            """
        pid_file = params.pid_file
        pid_file_bak = params.pid_file_bak
        pid = os.popen('cat {pid_file}'.format(pid_file=pid_file)).read()

        # process_id_exists_command = format("ls {pid_file} > /dev/null 2>&1 && ps -p {pid} >/dev/null 2>&1")
        # process_id_exists_command = format("echo 'stop'")

        kill_cmd = format("kill {pid}")
        Execute(kill_cmd)
        # wait_time = 5
        time.sleep(8)

        hard_kill_cmd = format("kill -9 {pid}")
        Execute(hard_kill_cmd,ignore_failures=True)
 
        File(pid_file_bak,
             action="delete"
             )

        File(pid_file,
             action="delete"
             )
        

    def start(self, env):
        import params
        env.set_params(params)

        # Configure flume
        self.configure(env)

        # Start flume
        # nohup ./bin/flume-ng agent -n a1 -c ./conf/ -f ./conf/myconf/avro_memory_hdfs.conf &
        # cmd = format("nohup {flume_base_dir}/bin/flume-ng agent -n {agent_name} -c {flume_base_dir}/conf  -f {flume_base_dir}/conf/myflume.conf &")
        cmd = format("{flume_base_dir}/bin/flume-ng agent -n {agent_name} -c {flume_base_dir}/conf  -f {flume_base_dir}/conf/myflume.conf > {flume_log_dir}/flume-{agent_name}-{flume_ng_user}.out 2>&1 &")
        Execute(cmd, user=params.flume_ng_user)

        time.sleep(5)
        # sometimes startup spawns a couple of threads - so only the first line may count
        # os.system("echo `sudo -u {flume_ng_user} pgrep -f flume | awk 'NR == 1'` > {pid_file}")
        pid_cmd = format("echo `pgrep -f flume` > {pid_file_bak}")
        Execute(pid_cmd,user=params.flume_ng_user)

        time.sleep(5)
        #os.system("echo 'hello')
        # os.system中传入变量出错，写死成功
        # os.system("echo `cat /var/run/flume1.7/flume.pidbak  | awk '{print $2}'` > /var/run/flume1.7/flume.pid")
        # python中要想输出{} 就加两层{{}}
        pid_cmd2 = format("echo `cat {pid_file_bak} | awk '{{print $2}}'` > {pid_file}")
        Execute(pid_cmd2,user=params.flume_ng_user)
        print("启动完成")

    def status(self, env):
        import status_params
        env.set_params(status_params)

        # Use built-in method to check status using pidfile
        check_process_status(status_params.pid_file)
if __name__ == "__main__":
    FlumeServer().execute()