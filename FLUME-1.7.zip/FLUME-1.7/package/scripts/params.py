# -*- coding: utf-8 -*-
#!/usr/bin/env python
"""
Kibana Params configurations
"""

from resource_management.libraries.functions.version import format_hdp_stack_version, compare_versions
from resource_management import *
import os

config = Script.get_config()


# flume env
flume_user = config['configurations']['flume1.7-env']['fluem.user']
flume_group = config['configurations']['flume1.7-env']['flume.group']
flume_base_dir = config['configurations']['flume1.7-env']['flume.base.dir']
flume_download_url = config['configurations']['flume1.7-env']['flume.download.url']
pid_file_dir = config['configurations']['flume1.7-env']['pid.file.dir']
pid_file = pid_file_dir + '/flume.pid'
pid_file_bak = pid_file_dir + '/flume.pidbak'
flume_ng_user = config['configurations']['flume1.7-env']['flume.ng.user']

flume_agent_conf_content = config['configurations']['flume1.7-conf']['content']

#log
flume_log_dir = config['configurations']['flume1.7-env']['flume.log.dir']

#agent
agent_name = config['configurations']['flume1.7-env']['agent.name']

java_home = '/opt/apps/jdk1.8.0_144'

