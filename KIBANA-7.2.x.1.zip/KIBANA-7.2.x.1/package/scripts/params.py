# -*- coding: utf-8 -*-
#!/usr/bin/env python
"""
Kibana Params configurations
"""

from resource_management.libraries.functions.version import format_hdp_stack_version, compare_versions
from resource_management import *
import os

config = Script.get_config()


# kibana env
kibana_user = config['configurations']['kibana-env']['kibana.user']
kibana_group = config['configurations']['kibana-env']['kibana.group']
kibana_base_dir = config['configurations']['kibana-env']['kibana.base.dir']
kibana_download_url = config['configurations']['kibana-env']['kibana.download.url']
pid_file_dir = config['configurations']['kibana-env']['pid.file.dir']
pid_file = pid_file_dir + '/kibana.pid'

# kibana config
server_host = config['configurations']['kibana-config']['server.host']
server_port = config['configurations']['kibana-config']['server.port']
server_name = config['configurations']['kibana-config']['server.name']
elasticsearch_url = config['configurations']['kibana-config']['elasticsearch.hosts']
kibana_index = config['configurations']['kibana-config']['kibana.index']
i18n_defaultLocale = config['configurations']['kibana-config']['i18n.defaultLocale']

logging_dest = config['configurations']['kibana-config']['logging.dest']
logging_dest_log = logging_dest + '/kibana.log'